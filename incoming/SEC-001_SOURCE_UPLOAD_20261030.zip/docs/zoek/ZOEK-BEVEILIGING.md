# Пошук «/zoek» — ізоляція й безпека

Стан: 22.10.2026. Спирається на специфікацію §9 («критично»). Доведення — атакуючі тести `tests/eenheid/zoek-isolatie-20261022.test.ts`
(два користувачі, три лади, справжній роутер і сесії, жива PostgreSQL) і `zoek-evaluatie-20261022.test.ts` (витоки в наборі оцінки).

## 1. Межі: лада, а не користувач

Одиниця ізоляції — **лада** `{userId, ruimte}` (`shared/ruimte-scheiding.ts`), не просто користувач: одна людина має особистий простір
(`prive`) і, якщо має технічний профіль, окремий технічний (`technisch`). Служба може бути в технічному просторі «спільною»
(читає особисту ладу), «власною» (окрема технічна лада) або «вимкненою/замороженою» (нічого). Пошук **повторює рішення брами
кожної служби**: `projectieLaden(herkomst, DEELBARE_DIENSTEN)` → на кожне джерело своя лада або відмова з кодом і поясненням.
Джерела без служби (каталог інтерфейсу: `ui/pagina/instelling/hulp`) лежать у базовій ладі вкладки (`gegevensRuimteVeilig`); технічні
об'єкти інтерфейсу (сторінки адміністрування, root-перемикачі) індексуються **лише в технічну ладу**, тож без живої технічної
активації їх не видно навіть у підказках.

## 2. Ідентичність лише з сервера

- `userId` — із сесії власника (`ownerRequireSession`, cookie + `tabContext`), ніколи з тіла. Поля `userId`, `ownerUserId`,
  `lade`, `rechten`, `ruimte` у тілі запиту ігноруються (тест «userId у тілі ігнорується»).
- `ruimte` — з живого стану технічного профілю/активації вкладки (`gegevensRuimteVeilig`); вкладка може лише **звузити** простір.
- Запити ШІ (`site_search` через конектор) проходять ту саму браму з `aiRuimte` гранту.

## 3. Авторизація на рівні БД (RLS) + явний WHERE

- `app.zoek_objecten` (0094), `app.zoek_geschiedenis` (0103), `app.zoek_ocr_tekst` (0102), `app.zoek_wachtrij` / `app.zoek_bron_stand`
  (0096/0100): політика `USING (current_user <> 'mijnruimte_app' OR user_id = app.huidige_gebruiker())` + `WITH CHECK`.
- Кожен запит ядра виконується під `alsGebruiker(userId)` (роль `mijnruimte_app`, `set_config('app.user_id')`) **і** несе
  `user_id = $1 AND ruimte = $2` — подвійно, щоб і системна роль (BYPASSRLS, cron) ніколи не перетинала лади.
- Прямий `SELECT` від ролі app з `app.user_id = B` по рядках A → 0 рядків; `UPDATE` → 0; `INSERT` з чужим `user_id` → відмова (тест RLS,
  запускається через `run-test-rls.sh` з `DATABASE_URL_APP`).
- Простір (`ruimte`) БД не знає як політику — його гарантує обов'язковий `ruimte = $2` у коді ядра (перевіряється тестом по тексту SQL
  у `zoek-kern-*` і поведінково в `zoek-isolatie`).

## 4. Перевірка перед записом і перед відкриттям

- `indexeer(lade, objecten)`: об'єкт з `rechten` іншої лади → `ZOEK_LADE_MISMATCH` до будь-якого SQL.
- Перехід із картки — `route {host, pad, hash?, params?}`: лише хост служби сайту, ніколи довільний URL; цільова сторінка (лист, файл,
  подія) знову проходить свою браму й RLS, тож відкликане право = 404 там, а не старий текст із індексу.
- Історія зберігає лише `(bron, id)`; при повторному відкритті id ще раз проганяються через `/api/owner/zoek` → чужі/зниклі id
  повертаються як `weg`, без назв.

## 5. Видалення, відключення, відкликання

| Подія | Що відбувається |
|---|---|
| документ видалено в джерелі | наступний скан: `verwijder(lade, bron, [id])`; OCR-кеш документа: `ocrCacheWissen(sleutel, sha256)` |
| служба від'єднана в технічному просторі (`ontkoppel`) / заморожена | брама закриває ладу → джерело не шукається одразу (ще до переіндексації), названо в `gesloten`; cron: `verwijderBron` + `niet_gekoppeld` |
| інтеграцію відкликано (Google/GitHub) | `koppelFeit` → `verbonden:false` → `verwijderBron`, стан `niet_gekoppeld` |
| акаунт заблоковано/видалено | сесія недійсна → жоден маршрут; рядки лишаються під RLS до прибирання власником |
| ключ людини закрито (sleutelkluis `gesloten`) | фонова індексація пошти/Drive пропускає ладу з кодом `KLUIS_GESLOTEN` (не читає зашифроване, нічого не пише, без 6 марних повторів) |

## 6. Жодних витоків через підказки, виправлення, фасети, історію, логи

- Автодоповнення/виправлення — лише з `titel_norm`/синонімів **своєї лади** (той самий `alsGebruiker` + WHERE); лексикон іншого
  користувача не підказується (тест із унікальним словом B).
- Фасети й `totaal` рахуються тією самою вибіркою, що й результати.
- Історія — у БД на ладу (0103); `localStorage` більше не використовується для історії (раніше витік між акаунтами одного браузера).
- Логи сервера (`console.*`) під час індексації й пошуку не містять назв/текстів документів — лише коди, лічильники, тривалість
  (тест перехоплює console).
- Повідомлення про помилки витягу тексту (`fout`) — ≤120 знаків, без вмісту файла.

## 7. Секрети не індексуються

`shared/geheim-patronen.ts` (`maskeerGeheimen`): PEM-блоки приватних ключів, токени GitHub (`ghp_`, `github_pat_` …), AWS, Anthropic,
OpenAI, Slack, Google API, Stripe (`sk_live_`/`sk_test_`), JWT, `Bearer …`, рядки з'єднання з паролем, `password=…`/`пароль: …`,
`api_key=…`, Google-app-паролі. Значення замінюється на `[geheim]` **до** запису в `tekst`/`omschrijving`/`trefwoorden`; `extra` не
містить секретів за контрактом. Пошук за значенням секрету нічого не знаходить; фрагмент і підказки його не показують. Той самий
список (строга частина) використовує передрозгортальна перевірка пакета (`backend/uitrol-voorcontrole.ts`).

## 8. Обхід фільтрації та ін'єкції

- Усі SQL параметризовані; tsquery будується з токенів `[a-z0-9]`, передається параметром; `sorteer` — лише з білого списку
  (`relevantie|nieuwste|oudest|titel`), `bronnen/soorten/talen/formaten` — лише значення з `ZOEK_BRONNEN`/`ZOEK_SOORTEN`/…, решта
  відкидається (`['*']` не означає «все чуже», а «нічого додаткового»); `pagina`/`perPagina` обрізаються до 1…/1–100; `q` ≤300 знаків,
  NUL/керуючі символи вирізаються. 18 атак у тесті (`'; DROP`, `) OR 1=1`, `\`, оператори tsquery, 10 000 знаків, RTL/zero-width, сміття у
  фільтрах) → 200 або 400, ніколи 500, жодного чужого рядка, таблиця ціла.
- Без `service` → 403; без сесії → 401/403.

## 9. Що лишається ризиком (і чому прийнятно)

- Системний пул (`getPool('systeem')`, BYPASSRLS) використовується cron-індексацією для запису; захист там — явний `user_id/ruimte` у
  кожному запиті + `ZOEK_LADE_MISMATCH` у ядрі. Читання для користувацьких маршрутів — завжди роль app.
- Індекс зберігає **відкритий** текст документів під RLS (як і проєкції пошти/хмари); DEK sleutelkluis охороняє токени/налаштування,
  не рядки. Власник сервера з доступом до БД бачить індекс так само, як бачить проєкції. Повне шифрування індексу ключем людини
  зробило б пошук без відкритого ключа неможливим — свідомо не реалізовано у цьому випуску; задокументовано як обмеження.
- Старий кеш `app.zoek_ocr_cache` (0096, без `user_id`) порожній і не використовується; лишається для відкату.

---

## NL — kort

Isolatie-eenheid is de **lade** (`userId` + `ruimte`), nooit alleen de gebruiker; de zoekroute herhaalt per bron het besluit van de
dienstpoort. Identiteit komt uitsluitend uit de sessie; `userId`/`ruimte` in het verzoek worden genegeerd. Elke query draait als
`mijnruimte_app` onder RLS én met `user_id = $1 AND ruimte = $2`. Suggesties, correcties, facetten en geschiedenis komen alleen uit de
eigen lade; logs bevatten geen documenttekst; geheimen (PEM, tokens, JWT, wachtwoordregels) worden vóór indexering gemaskeerd.
Bewezen met tests met twee gebruikers en drie laden (`zoek-isolatie-20261022`). Bekend risico: de index bewaart platte tekst onder RLS
(zoals de bestaande projecties); versleuteling met de sleutel van de mens is bewust niet gedaan.
