// Alles wat de gebruiker op de site doet, als meldingen: het auditlogboek (app.audit) omgezet naar gebeurtenissen met een sectie en dienst.
// "source" heeft de vorm "sectie[:dienst]" (mail:google, github, agent, mcp, identity, ...), zodat het meldingencentrum het juiste gekleurde
// pictogram en het logo van de dienst kan tonen. Ruis (elke leesactie, sessierotatie, menuvoorkeuren) komt er bewust niet in.
import { V2_AGENTEN } from '../shared/connector-v2/agenten';
import { klantVan } from '../shared/ai-verbinding';
import { doelVan } from '../shared/beheer-journaal';

export type SiteEvent = { id: string; source: string; platform: string; kind: 'site'; type: string; subject: string; status: 'succeeded' | 'failed' | 'rejected'; createdAt: number; finishedAt: number;
  /** Alleen bij AI-acties (owner.mcp.tool): wat, waarop, en bij mislukking WAAROM — zodat de melding de kern noemt, niet alleen «помилка». */
  tool?: string; doel?: string; client?: string; geweigerd?: boolean; code?: string; reden?: string; /** UI-014: einde van een toegang (ISO), bv. extensie. */ eind?: string;
  /** 22.10.2026: technische auditcontext (profiel/activatie, server/platform/audit.ts) → sfeer 'technisch' (shared/meldingen-soorten.ts). Nooit de id's zelf naar de browser. */
  context?: { profiel?: string; activatie?: string };
  /** 23.10.2026: de handeling gebeurde in de TECHNISCHE ruimte (details.ruimte/lade 'technisch', of een v2-hulpmiddel van de beheerkant
   *  «…_beheer»): een AI-actie via de technische koppeling, een apparaat/browser in het technische slot. Alleen deze vlag gaat mee. */
  ruimte?: 'technisch' };

// 23.10.2026: owner.ruimte.geweigerd = elke poortweigering van de technische ruimte (backend/ruimte-scheiding.ts, per verzoek: één paginalading
// van de hub in een technisch tabblad zonder keuze gaf er 46 in één korte stand-run). De pagina legt de weigering zelf uit (RuimteStrook,
// client.ts); in de bel/het paneel was het herhaalruis («Дія на сайті: ruimte geweigerd · виконано»). Het journaal houdt elke regel.
// 23.10: owner.extensie.zijpaneel.chat = elk chatbericht in het zijpaneel van de extensie (zone E) — geen melding, wel in het journaal.
// MELDINGEN-REGISTER-001: owner.meldingen.ecosysteem.(actie|profiel) = klik in het meldingenpaneel zelf — mag nooit een nieuwe melding over zichzelf maken.
export const SITE_RUIS = /^(owner\.ruimte\.geweigerd$|owner\.extensie\.zijpaneel\.chat$|owner\.meldingen\.ecosysteem\.(actie|profiel)$|owner\.mcp\.tools\.list$|owner\.extensie\.beheer\.bekeken$|owner\.terminal\.opdrachten\.bekeken$|klimop_(overzicht|dubbel_logboek|quorum_logboek|spiegel_logboek)$|owner\.notifications\.|owner\.session\.(rotated|refresh)|owner\.ui\.|owner\.tab\.|owner\.mail\.(item\.|send\.prepared)|owner\.admin\.(audit\.viewed|diagnostics)|owner\.redirect\.|owner\.auth\.transaction\.(created|started)|owner\.browser\.grant\.(used|cookie))/;
const SKIP = SITE_RUIS;
const RULES: Array<[RegExp, string]> = [
  [/^owner\.mail\.|^mail\./, 'mail:google'], [/^owner\.cloud\.|^cloud\./, 'cloud:google'], [/^owner\.calendar\.|^agenda\./, 'calendar:google'], [/^owner\.github\./, 'github'],
  [/^owner\.ai\.|^owner\.chat\./, 'ai:anthropic'], [/^owner\.(agent|agents)\.|^owner\.(terminal|remote|apparaat)\.|^apparaat\./, 'agent'],
  [/^owner\.(mcp|vaardigheden|connector)\.|^koppeling_gewijzigd$/, 'claude'], [/^owner\.(browser|extensie)\./, 'browser'],
  [/^owner\.api\.|^owner\.vault\./, 'api'],
  [/^owner\.(admin|uitrol|tech|ruimte|flags|ondersteuning|impersonatie|diagnose|beleid)\.|^uitrol[._]|^klimop_|^orch_|^eigenaar_besluit_|^diag\.|^zoek\.index\./, 'admin'],
  [/^owner\.(identity|privacy|profile|session|step_up|auth|access|rol)\.|^account\.|^privacy\./, 'identity'],
  [/^huis\./, 'huis'], [/^notitie\./, 'hub'],
  // SEC-002 (privacy-logboek-03): veiligheidskritieke acties ZONDER «owner.»-voorvoegsel vielen hier stil weg (sourceOfAudit → null):
  // een wachtwoord erbij, TOTP uit, passkey weg, sleutelkluis, een AI-token of een namens-sessie — de eigenaar zag niets in de stroom.
  [/^access\.|^aanmeld\.|^aanmelden\.|^sleutelkluis\.|^(toegangscode|gast)_|^bevestigen\.|^code\.|^inlog\.|^koppelen\.|^koppeling\.|^telegram|^venster\.|^widget\.|^wijziging\.|^plaats-eis\.|^stap-op$|^niet-ik$|^fout-symbool$/, 'identity'],
  [/^agent\.|^ai_/, 'agent'], [/^mcp_console_/, 'agent'],
];
/** «claude:<klant>» voor een gebeurtenis van een AI-koppeling: agent-slug of klantnaam uit de details; onbekend → «claude» zonder logo. */
export function aiBron(details?: Record<string, unknown>): string {
  const d = details ?? {};
  const agent = typeof d.agent === 'string' ? V2_AGENTEN.find((a) => a.slug === d.agent) : undefined;
  const k = agent ? agent.klant : klantVan(String(d.client ?? d.clientName ?? d.klant ?? ''));
  return k === 'overig' ? 'claude' : `claude:${k}`;
}
/** Sectie (en dienst) voor een auditactie, of null als de actie geen melding verdient. */
export function sourceOfAudit(action: string): string | null {
  if (SKIP.test(action)) return null;
  for (const [re, source] of RULES) if (re.test(action)) return source;
  return action.startsWith('owner.') ? 'site' : null;
}
const FAIL = /fail|denied|error|reject|invalid|blocked|conflict|mislukt|fout|afgebroken/i;
/** Nederlandse weigering uit het beheerlogboek (journaalSchrijf resultaat 'geweigerd'): «відхилено», geen «помилка» en geen pop-up. */
const GEWEIGERD = /^(geweigerd|afgewezen)$/i;
/** Alleen een code (letters, cijfers, _ of -), nooit vrije tekst: die kan gevoelige gegevens bevatten. */
const CODE = /^[A-Za-z0-9_-]{2,60}$/;
const codeVan = (v: unknown): string => (typeof v === 'string' && CODE.test(v.trim()) ? v.trim() : '');
/** Oorzaak uit de details van een auditregel (code/reason/reden/error), of '' als die geen code is. */
export function reasonOfAudit(details?: Record<string, unknown>): string {
  return codeVan(details?.code ?? details?.reason ?? details?.reden ?? details?.error);
}
export function siteEventsFromAudit(rows: Array<{ id: string; action: string; result: string; createdAt: number; details?: Record<string, unknown>; context?: { profiel?: string; activatie?: string } }>): SiteEvent[] {
  const out: SiteEvent[] = [];
  for (const r of rows) {
    const basis = sourceOfAudit(r.action);
    if (!basis) continue;
    // AGENTSCHEIDING-001: AI-koppelingen tonen het logo en de naam van DE AI die het deed (agent/klant uit het journaal), niet altijd «Claude».
    const source = basis === 'claude' ? aiBron(r.details) : basis;
    const afgeleidDoel = doelVan(r.details, r.action);
    const subject = typeof r.details?.provider === 'string'
      ? r.details.provider.slice(0, 40)
      : (afgeleidDoel?.naam ? afgeleidDoel.naam.slice(0, 60) : '');
    const failed = FAIL.test(r.result);
    const ev: SiteEvent = { id: `audit:${r.id}`, source, platform: '', kind: 'site', type: r.action, subject, status: GEWEIGERD.test(String(r.result || '')) ? 'rejected' : failed ? 'failed' : 'succeeded', createdAt: r.createdAt, finishedAt: r.createdAt };
    // Alleen de VLAG «technisch profiel actief», nooit de profiel-/activatie-id zelf.
    if (r.context && (r.context.profiel || r.context.activatie)) ev.context = { profiel: r.context.profiel ? 'ja' : undefined, activatie: r.context.activatie ? 'ja' : undefined };
    if (r.details && (r.details.ruimte === 'technisch' || r.details.lade === 'technisch' || /_beheer$/.test(String(r.details.v2 || '')))) ev.ruimte = 'technisch';
    // UI-014: extensie-gebeurtenissen — welke ruimte, tot wanneer, en de reden (code), zodat de melding zegt WAT en WAAROM. Geen ids van sleutels.
    if (/^owner\.extensie\./.test(r.action) && r.details) {
      const d = r.details, tekstVan = (v: unknown, n: number) => (typeof v === 'string' && v ? v.slice(0, n) : undefined);
      const doel = tekstVan(d.ruimte, 20), code = tekstVan(d.reden, 60) || tekstVan(d.venster, 10), eind = tekstVan(d.eind, 40);
      if (doel) ev.doel = doel; if (code) ev.code = code; if (eind) ev.eind = eind;
    }
    if (r.action === 'owner.mcp.tool' && r.details) {
      // Veilige velden uit het journaal (backend/mcp-connector.ts werkDetails): hulpmiddel, doel, client en foutcode — nooit inhoud.
      const kort = (v: unknown, n: number) => (typeof v === 'string' && v ? v.slice(0, n) : undefined);
      const tool = kort(r.details.tool, 80), doel = kort(r.details.doel, 120), client = kort(r.details.client, 60);
      const code = typeof r.details.fout === 'string' && /^[A-Z][A-Z0-9_]{2,47}$/.test(r.details.fout) ? r.details.fout : undefined;
      const reden = codeVan(r.details.reden).slice(0, 40) || undefined;
      if (tool) ev.tool = tool;
      if (doel) ev.doel = doel;
      if (client) ev.client = client;
      if (/denied/i.test(r.result)) ev.geweigerd = true;
      if (code) ev.code = code;
      if (reden) ev.reden = reden;
    }
    if (!ev.doel && afgeleidDoel?.naam) ev.doel = afgeleidDoel.naam.slice(0, 80);
    // Elke andere mislukte actie krijgt de foutcode uit het journaal (alleen een code), zodat de melding zegt waarom. Voor AI-acties staat dat hierboven.
    if (ev.code === undefined && r.action !== 'owner.mcp.tool') { const code = reasonOfAudit(r.details); if (code) ev.code = code; }
    out.push(ev);
  }
  return out;
}
