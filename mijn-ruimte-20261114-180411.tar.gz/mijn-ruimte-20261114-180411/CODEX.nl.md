> 🌐 **Taal / Мова:** [Українська](АДАПТЕР-КОДЕКС.uk.md) · **Nederlands** | [Hoofdpagina](LEESMIJ.md) · [Documentatie-index](docs/INDEX.nl.md)

<!-- orch-adapter -->
# Перехідник для Codex · Adapter voor Codex

Цей файл — лише вказівник. Усі правила — в **AGENTS.md** (канонічне джерело) і `orchestratie/beleid.json`. Тут нічого не додається й не скасовується.
Dit bestand is alleen een verwijzing. Alle regels staan in **AGENTS.md** en `orchestratie/beleid.json`.

1. Прочитай AGENTS.md повністю (без доступу до репозиторію — `orchestratie/CONTEXT-COMPACT.md`).
2. Ідентифікатор агента для Task ID, пакетів і `AGENT`: `codex`.
3. Перед початком: `node scripts/orch.mjs controleer` і `versheid --taak <ID> --fase start`. Перед передаванням: `versheid --fase overdracht` + `ORCH-OVERDRACHT.json`.
4. Мова відповідей і звітів — українська; коментарі в коді — українська/нідерландська; UI — українська/нідерландська.
5. Жодних змін у production, `voornaamst`, `integratie`, `release/*`, чужих гілках чи резервних копіях без явного погодження власника.
