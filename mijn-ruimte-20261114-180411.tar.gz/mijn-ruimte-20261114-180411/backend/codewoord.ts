// Кодове слово: scrypt + перець з середовища. Значення в журнал не пишеться.
import { createHash, randomBytes, scrypt, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { getPool } from '../server/platform/pg';
import { CODEWOORD_BLOK_MS, CODEWOORD_MAX_MISLUKT, codewoordSterk, normaliseerCodewoord, pogingToegestaan } from '../shared/codewoord';
import { codewoordSessieId, loginVers } from '../shared/codewoord-poort';
import type { RouterMiddleware, RouterResponse } from '../server/platform/router';
import { codewoordStapOpVastleggen, type StapOpAuth } from './stap-op';

const scryptAsync = promisify(scrypt) as (password: string, salt: Buffer, keylen: number, options: { N: number; r: number; p: number }) => Promise<Buffer>;
const TBL = 'codewoord_v1';
const N = 16384, R = 8, P = 1;

type Rij = { userId: string; salt: string; hash: string; n: number; r: number; p: number; mislukt: number; geblokkeerdTot: number; updatedAt: number; loginSessies?: Record<string, number> };

export const peperActief = () => !!process.env.CODEWOORD_PEPER;

const materiaal = (woord: string) => `${normaliseerCodewoord(woord)}\0${process.env.CODEWOORD_PEPER || ''}`;
const idVan = (userId: string) => `codewoord:${userId}`;

async function lees(userId: string): Promise<Rij | null> {
  const r = await getPool().query('SELECT data FROM app.records WHERE tbl = $1 AND id = $2', [TBL, idVan(userId)]);
  const d = r.rows[0]?.data as Rij | undefined;
  return d && d.hash ? d : null;
}

async function schrijf(rij: Rij) {
  await getPool().query(
    `INSERT INTO app.records (tbl, id, data) VALUES ($1, $2, $3::jsonb)
     ON CONFLICT (tbl, id) DO UPDATE SET data = EXCLUDED.data, updated_at = now()`,
    [TBL, idVan(rij.userId), JSON.stringify(rij)],
  );
}

export async function codewoordHeeft(userId: string): Promise<boolean> {
  return !!(await lees(userId));
}

export async function codewoordZetten(userId: string, woord: string, email: string, huidig?: string): Promise<'ZWAK' | 'ONJUIST' | 'GEBLOKKEERD' | 'OK'> {
  if (!codewoordSterk(woord, email)) return 'ZWAK';
  const bestaand = await lees(userId);
  if (bestaand) {
    const c = await codewoordControleren(userId, huidig || '');
    if (!c.ok) return c.code === 'GEBLOKKEERD' ? 'GEBLOKKEERD' : 'ONJUIST';
  }
  const salt = randomBytes(16);
  const hash = await scryptAsync(materiaal(woord), salt, 32, { N, r: R, p: P });
  await schrijf({ userId, salt: salt.toString('base64url'), hash: hash.toString('base64url'), n: N, r: R, p: P, mislukt: 0, geblokkeerdTot: 0, updatedAt: Date.now(), loginSessies: bestaand?.loginSessies });
  return 'OK';
}

export async function codewoordControleren(userId: string, woord: string): Promise<{ ok: true } | { ok: false; code: 'ONJUIST' | 'GEBLOKKEERD' | 'NIET_INGESTELD'; wachtMs?: number }> {
  const nu = Date.now();
  // SEC-002 (aanmelden-03): спробу резервуємо АТОМАРНО, одним UPDATE, ще до scrypt. Раніше рядок читали, рахували хеш (десятки мс)
  // і перезаписували цілком значенням mislukt+1 зі старого читання: K одночасних спроб рахувалися як одна, і блок 5/15 хв не діяв.
  // Тепер кожна спроба збільшує лічильник під блокуванням рядка; п'ята вмикає блок, решта одразу отримують GEBLOKKEERD.
  const rij = await reserveerPoging(userId, nu);
  if (!rij) {
    const staat = await lees(userId);
    if (!staat) return { ok: false, code: 'NIET_INGESTELD' };
    const poort = pogingToegestaan(staat.mislukt, staat.geblokkeerdTot, nu);
    return { ok: false, code: 'GEBLOKKEERD', wachtMs: poort.ok ? CODEWOORD_BLOK_MS : poort.wachtMs };
  }
  const hash = await scryptAsync(materiaal(woord), Buffer.from(rij.salt, 'base64url'), 32, { N: rij.n || N, r: rij.r || R, p: rij.p || P });
  const verwacht = Buffer.from(rij.hash, 'base64url');
  const gelijk = hash.length === verwacht.length && timingSafeEqual(hash, verwacht);
  if (!gelijk) return { ok: false, code: 'ONJUIST' }; // спробу вже пораховано вище
  // Успіх скидає лише лічильник (решта рядка, зокрема loginSessies, лишається) і лише якщо слово тим часом не змінили.
  await getPool().query(
    `UPDATE app.records SET data = data || jsonb_build_object('mislukt', 0, 'geblokkeerdTot', 0, 'updatedAt', $3::bigint), updated_at = now()
      WHERE tbl = $1 AND id = $2 AND data->>'hash' = $4`,
    [TBL, idVan(userId), nu, rij.hash],
  );
  return { ok: true };
}

/**
 * SEC-002 (aanmelden-03): одна атомарна спроба. Повертає рядок (для перевірки хеша), якщо спробу дозволено й пораховано;
 * null — рядка немає або діє блок. Правила ті самі, що в shared/codewoord.ts: блок = 5 помилок і час блоку ще не минув;
 * коли блок минув, лічильник починається знову.
 */
async function reserveerPoging(userId: string, nu: number): Promise<Rij | null> {
  const mislukt = `COALESCE((data->>'mislukt')::numeric, 0)`, tot = `COALESCE((data->>'geblokkeerdTot')::numeric, 0)`;
  const volgende = `((CASE WHEN ${tot} > 0 AND ${tot} <= $3::bigint THEN 0 ELSE ${mislukt} END) + 1)`;
  const r = await getPool().query(
    `UPDATE app.records SET data = data || jsonb_build_object(
        'mislukt', ${volgende},
        'geblokkeerdTot', CASE WHEN ${volgende} >= $4::int THEN $3::bigint + $5::bigint ELSE 0 END,
        'updatedAt', $3::bigint), updated_at = now()
      WHERE tbl = $1 AND id = $2 AND COALESCE(data->>'hash', '') <> '' AND NOT (${mislukt} >= $4::int AND ${tot} > $3::bigint)
      RETURNING data`,
    [TBL, idVan(userId), nu, CODEWOORD_MAX_MISLUKT, CODEWOORD_BLOK_MS],
  );
  return (r.rows[0]?.data as Rij | undefined) || null;
}

/** null = кодового слова немає, стирати можна. Інакше код помилки для відповіді 403. */
export async function codewoordEis(userId: string, woord: unknown): Promise<null | 'CODEWOORD_ONJUIST' | 'CODEWOORD_GEBLOKKEERD' | 'CODEWOORD_VERPLICHT'> {
  if (!(await codewoordHeeft(userId))) return null;
  if (typeof woord !== 'string' || !woord) return 'CODEWOORD_VERPLICHT';
  const c = await codewoordControleren(userId, woord);
  if (c.ok) return null;
  if (c.code === 'GEBLOKKEERD') return 'CODEWOORD_GEBLOKKEERD';
  return 'CODEWOORD_ONJUIST';
}

/** true = слово задане, а ця сесія його ще не назвала. Немає рядка — ворота зачинені. */
export async function codewoordPoortOpen(userId: string, sessieId: string): Promise<boolean> {
  const rij = await lees(userId);
  if (!rij) return false;
  return !loginVers(Number(rij.loginSessies?.[sessieId] || 0), Date.now());
}

/** Після правильного слова на цьому вході. Старі сесії відпадають самі. */
export async function codewoordLoginVastleggen(userId: string, sessieId: string, extraSessieId = ''): Promise<void> {
  const ids = [sessieId, extraSessieId].filter(Boolean);
  if (!ids.length) return;
  const rij = await lees(userId);
  if (!rij) return;
  const nu = Date.now();
  const bijgewerkt: Record<string, number> = { ...(rij.loginSessies || {}) };
  for (const id of ids) bijgewerkt[id] = nu;
  const loginSessies = Object.fromEntries(
    Object.entries(bijgewerkt).filter(([, at]) => loginVers(Number(at), nu)).slice(-40),
  );
  // SEC-002 (aanmelden-03): лише поле loginSessies, не весь рядок — інакше одночасна спроба губила б лічильник помилок (і навпаки).
  await getPool().query(
    `UPDATE app.records SET data = jsonb_set(data, '{loginSessies}', $3::jsonb, true) || jsonb_build_object('updatedAt', $4::bigint), updated_at = now()
      WHERE tbl = $1 AND id = $2`,
    [TBL, idVan(userId), JSON.stringify(loginSessies), nu],
  );
}

/** Живий віртуальний запис профілю цього ж облікового запису в поточному оглядачі (для збереження пройдених воріт під час перемикання профілів). */
async function browserProfielSessieId(userId: string, anchorId?: string): Promise<string> {
  if (!userId || !anchorId) return '';
  try {
    const tabHash = createHash('sha256').update(`owner-browser-account-v1:${userId}`).digest('hex');
    const r = await getPool().query(
      `SELECT id FROM app.records
        WHERE tbl = 'owner_tab_sessions_v1'
          AND data->>'anchorSessionId' = $1
          AND data->>'userId' = $2
          AND data->>'tabHash' = $3
          AND data->>'status' = 'active'
          AND coalesce(nullif(data->>'revokedAt', '')::bigint, 0) = 0
          AND coalesce(nullif(data->>'idleExpiresAt', '')::bigint, 0) > $4
          AND coalesce(nullif(data->>'absoluteExpiresAt', '')::bigint, 0) > $4
        LIMIT 1`,
      [anchorId, userId, tabHash, Date.now()],
    );
    return String(r.rows[0]?.id || '');
  } catch {
    return '';
  }
}

export { codewoordRouteVrij, codewoordSessieId } from '../shared/codewoord-poort';

type Ctx = { event: unknown; body: unknown };
type Auth = { user: { id: string; email: string; status?: string } } | { errorCode: string };
type VolAuth = { user: { id: string; email: string }; session?: { id: string; userId: string }; tabSession?: { id: string; userId: string } | null };
export function codewoordRoutes(deps: {
  requireSession: (event: unknown, body: unknown) => Promise<Auth>;
  fail: (code: string, status: number) => RouterResponse;
  ok: (data: unknown) => RouterResponse;
  body: (body: unknown) => Record<string, unknown>;
  stepUp: (ctx: Ctx, auth: Auth) => Promise<RouterResponse | null>;
}): Record<string, RouterMiddleware[]> {
  const metSessie = (run: (user: { id: string; email: string }, body: Record<string, unknown>, ctx: Ctx, auth: VolAuth) => Promise<RouterResponse>): RouterMiddleware => async (ctx) => {
    const auth = await deps.requireSession(ctx.event, ctx.body);
    if ('errorCode' in auth) return deps.fail(auth.errorCode, 401);
    // SEC-002 (autorisatie-09): несхвалений обліковий запис (new/pending) кодове слово не задає й не перевіряє — шлюз сеансу
    // (ownerRequireSession) свідомо пропускає такі записи до екрана очікування, тож схвалення перевіряємо тут.
    if (auth.user.status !== 'approved') return deps.fail('ACCOUNT_NOT_APPROVED', 403);
    const stap = await deps.stepUp(ctx, auth);
    if (stap) return stap;
    return run(auth.user, deps.body(ctx.body), ctx, auth as VolAuth);
  };
  const sessieVan = (auth: VolAuth) => codewoordSessieId({
    userId: auth.user.id, anchorUserId: auth.session?.userId, anchorId: auth.session?.id, tabUserId: auth.tabSession?.userId, tabId: auth.tabSession?.id,
  });
  return {
    'POST /api/owner/identity/codewoord/zetten': [metSessie(async (user, body, _ctx, auth) => {
      const uit = await codewoordZetten(user.id, String(body.woord || ''), user.email, typeof body.huidig === 'string' ? body.huidig : '');
      if (uit !== 'OK') return deps.fail(uit === 'ZWAK' ? 'CODEWOORD_ZWAK' : uit === 'GEBLOKKEERD' ? 'CODEWOORD_GEBLOKKEERD' : 'CODEWOORD_ONJUIST', 400);
      const profielSid = await browserProfielSessieId(user.id, auth.session?.id);
      await codewoordLoginVastleggen(user.id, sessieVan(auth), profielSid);
      return deps.ok({ ok: true, codewoordPoort: false });
    })],
    'POST /api/owner/identity/codewoord/controleren': [metSessie(async (user, body) => {
      const c = await codewoordControleren(user.id, String(body.woord || ''));
      if (!c.ok) return deps.fail(c.code === 'NIET_INGESTELD' ? 'CODEWOORD_NIET_INGESTELD' : c.code === 'GEBLOKKEERD' ? 'CODEWOORD_GEBLOKKEERD' : 'CODEWOORD_ONJUIST', 403);
      return deps.ok({ ok: true });
    })],
    'POST /api/owner/session/codewoord': [async (ctx: Ctx) => {
      const auth = await deps.requireSession(ctx.event, ctx.body);
      if ('errorCode' in auth) return deps.fail(auth.errorCode, 401);
      const vol = auth as VolAuth;
      const c = await codewoordControleren(vol.user.id, String(deps.body(ctx.body).woord || ''));
      if (!c.ok) return deps.fail(c.code === 'NIET_INGESTELD' ? 'CODEWOORD_NIET_INGESTELD' : c.code === 'GEBLOKKEERD' ? 'CODEWOORD_GEBLOKKEERD' : 'CODEWOORD_ONJUIST', 403);
      const sid = sessieVan(vol);
      const profielSid = await browserProfielSessieId(vol.user.id, vol.session?.id);
      await codewoordLoginVastleggen(vol.user.id, sid, profielSid);
      await codewoordStapOpVastleggen({ user: { id: vol.user.id }, session: vol.session, tabSession: vol.tabSession } as StapOpAuth);
      return deps.ok({ ok: true, codewoordPoort: false });
    }],
  };
}
